using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WinLose : MonoBehaviour
{
    HitObstacle obstacle;
    Timer timer;
    IsAtEncounter encounter;

    [SerializeField]
    int ObstaclesToLose = 5;

    [SerializeField]
    GameObject BloodyEndingScreen, GoodEndingScreen, LateEndingScreen;


    public void DeadEnding()
    {
        LateEndingScreen.SetActive(true);
    }

    public void BloodyEnding()
    {
        BloodyEndingScreen.SetActive(true);
    }

    public void GoodEnding()
    {
        GoodEndingScreen.SetActive(true);
    }
}


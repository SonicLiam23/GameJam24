using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EncounterOptions : MonoBehaviour
{
    [SerializeField]
    GameObject m_Player;
    Movement playerMovement;
    Spawner spawner;
    IsAtEncounter encounter;





    private void Start()
    {
        playerMovement = m_Player.GetComponent<Movement>();
        spawner = GameObject.Find("Spawner").GetComponent<Spawner>();
        encounter = GameObject.Find("Player").GetComponent <IsAtEncounter>();
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.UpArrow)) 
        {
            Choice1();
        }
        else if (Input.GetKeyDown(KeyCode.DownArrow)) { Choice2(); }
    }

    public void Choice1()
    {
        transform.parent.gameObject.SetActive(false);
        spawner.DestroyPlatforms();
        spawner.SpawnPlatforms();
        playerMovement.SetDefaultSpeed();
        encounter.DialougeBox.SetActive(false); 
        encounter.AddChoice(1);

    }

    public void Choice2()
    {
        transform.parent.gameObject.SetActive(false);
        spawner.DestroyPlatforms();
        spawner.SpawnPlatforms(); 
        playerMovement.SetDefaultSpeed();
        encounter.DialougeBox.SetActive(false);
        encounter.AddChoice(2);
    }
}

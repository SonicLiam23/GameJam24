using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class runanim : MonoBehaviour
{
    [SerializeField]
    GameObject frame1, frame2, frame3, frame4;
    List<GameObject> frames;
    float timer;
    float fps;
    int CurrentFrame;
    // Start is called before the first frame update
    void Start()
    {
        CurrentFrame = 0;
        fps = 6;
        frames = new List<GameObject>();
        frames.Add(frame1);
        frames.Add(frame2);
        frames.Add(frame3);
        frames.Add(frame4);
    }

    // Update is called once per frame
    void Update()
    {
        timer += Time.deltaTime;
        if (timer > (1/fps))
        {
            frames[CurrentFrame].SetActive(false);
            CurrentFrame++;
            if (CurrentFrame == 3)
            {
                CurrentFrame = 0;
            }
            frames[CurrentFrame].SetActive(true);
            timer = 0;


        }
    }
}

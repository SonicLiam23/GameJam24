using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class IsAtEncounter : MonoBehaviour
{
    public int EncountersHad = 0;
    public bool AtEncounter;
    Movement movement;
    [SerializeField]
    GameObject EncounterScreen;
    [SerializeField]
    Timer TimerScript;

    [SerializeField]
    TextMeshProUGUI NPCdialogueText;
    [SerializeField]   
    TextMeshProUGUI PlayerChoice1Text, PlayerChoice2Text;

    [SerializeField]
    WinLose endings;



    public GameObject DialougeBox;

    public int EndingID;

    void Start()
    {
        movement = GetComponent<Movement>();
        AtEncounter = false;
        EndingID = 0;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Encounter")
        {
            AtEncounter = true;
            other.gameObject.SetActive(false);
            HandleEncounter();
        }
    }

    void HandleEncounter()
    {
        movement.movementSpeed = 0;
        DialougeBox.SetActive(true);
        ChangeText();
    }

    public void AddChoice(int ID)
    {
        EndingID += (int)Mathf.Pow(10, EncountersHad) * ID;
        EncountersHad++;
        ActionChoice();
    }

    void ChangeText()
    {
        if (EndingID == 0)
        {
            // first encounter
            NPCdialogueText.text = "�*Groans* What are you doin �ere, human..�";
            PlayerChoice1Text.text = "You start-a swinging, giving the foul creature a good wallop";

            //KILLS YOU
            PlayerChoice2Text.text = "�Please don�t hurt me� you mutter";
        }

        else if (EndingID == 1)
        {
            // Fought first
            NPCdialogueText.text = "�You got me last time but I�m ready for ya now�\r\nHe readies his fists, holding them out and shaking them wildly\r\n";
            PlayerChoice1Text.text = "He needs a knuckle sandwich\n�You hungry?� you ask\r\n�What?�\r\n";
            PlayerChoice2Text.text = "You apologise for your previous actions\r\nThe goblin looks at you in confusion\r\n";
        }
    }

    void ActionChoice()
    {
        if (EndingID == 1)
        {
            TimerScript.m_time -= 30 / 2;
        }

        else if (EndingID == 2) 
        {
            endings.DeadEnding();

        }

        else if (EndingID == 11)
        {
            endings.BloodyEnding();
        }

        else if (EndingID == 12)
        {
            endings.GoodEnding();
        }
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HitObstacle : MonoBehaviour
{
    [SerializeField]
    Timer TimerScript;
    public int ObstaclesHit = 0;
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Obstacle")
        {
            TimerScript.m_time -= 20/2;
            ObstaclesHit++;
        }
    }
}

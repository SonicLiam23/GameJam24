using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class Movement : MonoBehaviour
{
    [SerializeField]
    private Rigidbody m_rigidBody;

    public const int DefaultMovementSpeed = 150;

    [SerializeField]
    public int movementSpeed;

    [SerializeField]
    private int JumpHeight, ChangeLaneSpeed;

    Vector3 MovementVec;

    [SerializeField]
    Camera m_Camera; 

    int Lane;
    bool MoveLeft, MoveRight;

    public bool IsOnFloor;
    // Start is called before the first frame update
    void Start()
    {
        movementSpeed = 0;
        MovementVec = Vector3.zero;
        IsOnFloor = true;
        MoveLeft = false; MoveRight = false;
        Lane = 0;
        m_rigidBody = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        MoveForward();
        MoveLR();

        if (Input.GetKeyDown(KeyCode.UpArrow) && IsOnFloor)
        {
            IsOnFloor = false;
            Vector3 vector3 = new Vector3(0 , JumpHeight, 0);
            transform.position += vector3;
            m_Camera.fieldOfView += 5;
            Invoke("MoveBackDown", 1);
        }
    }

    void MoveBackDown()
    {
        m_Camera.fieldOfView -= 5;
        IsOnFloor = true;
        Vector3 vector3 = new Vector3(0, -JumpHeight, 0);
        transform.position += vector3;
    }


    void MoveForward()
    {
        MovementVec.z = movementSpeed;
        MovementVec.y = m_rigidBody.velocity.y;
        MovementVec.x = m_rigidBody.velocity.x;

        m_rigidBody.velocity = MovementVec;
    }

    void MoveLR()
    {
        
        if (Input.GetKeyDown(KeyCode.LeftArrow) && Lane != -1)
        {
            Lane--;
            MoveLeft = true;
            //Debug.Log("Left");
        }
        else if (Input.GetKeyDown(KeyCode.RightArrow) && Lane != 1)
        {
            Lane++;
            MoveRight = true;
            //Debug.Log("Right");
        }
        
        if (MoveLeft)
        {
            Vector3 NewPos = transform.position;
            NewPos.x -= 20;
            float step = ChangeLaneSpeed * Time.deltaTime;

            transform.position = Vector3.MoveTowards(transform.position, NewPos, step);

            if (transform.position.x <= Lane * 20)
            {
                MoveLeft = false;
            }
        }
        else if (MoveRight)
        {
            Vector3 NewPos = transform.position;    
            NewPos.x += 20;
            float step = ChangeLaneSpeed * Time.deltaTime;

            transform.position = Vector3.MoveTowards(transform.position, NewPos, step);

            if (transform.position.x >= Lane * 20)
            {
                MoveRight = false;
            }
        }
    }

    public void SetDefaultSpeed()
    {
        movementSpeed = DefaultMovementSpeed;
    }
}

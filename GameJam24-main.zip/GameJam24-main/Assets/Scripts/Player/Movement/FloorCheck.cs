using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FloorCheck : MonoBehaviour
{
    // Start is called before the first frame update
    Movement PlayerMovement;
    void Start()
    {
        PlayerMovement = gameObject.GetComponentInParent<Movement>();
    }

    private void OnTriggerEnter(Collider other)
    {
        PlayerMovement.IsOnFloor = true;
    }

}

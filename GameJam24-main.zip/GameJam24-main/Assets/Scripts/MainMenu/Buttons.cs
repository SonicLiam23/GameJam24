using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Buttons : MonoBehaviour
{
    [SerializeField]
    GameObject CreditsScreen, MenuButtons;

    Movement movement;

    bool ShowingCredits;

    private void Start()
    {
        movement = GameObject.Find("Player").GetComponent<Movement>();
        ShowingCredits = false;
    }

    public void StartGame()
    {
        movement.SetDefaultSpeed();
        GameObject.Find("====MAIN MENU====").SetActive(false);
    }

    public void ToggleCredits()
    {
        ShowingCredits = !ShowingCredits;

        MenuButtons.SetActive(!ShowingCredits);
        CreditsScreen.SetActive(ShowingCredits);
    }

    public void ExitGame()
    {
        Application.Quit();
    }
}

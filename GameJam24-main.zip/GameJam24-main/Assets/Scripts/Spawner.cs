using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    [SerializeField]
    private GameObject PlainPlatform, TreeObstacle, FenceLeft, FenceRight, Encounter, SpawnPlatform;

    [SerializeField]
    public int PlatformsToSpawn, AmountOfObstacles;
    float PlatformLength;
    List<GameObject> PlatformsPool;
    List<GameObject> Obstacles;
    int UniqueObstacles;

    public bool AtEncounter = true;
    
    
    // Update is called once per frame

    private void Start()
    {
        Obstacles = new List<GameObject>();
        Obstacles.Add(TreeObstacle); Obstacles.Add(FenceLeft); Obstacles.Add(FenceRight);

        UniqueObstacles = 3;
        PlatformLength = PlainPlatform.transform.localScale.z;
        Random.InitState(System.DateTime.Now.Millisecond);
        SpawnPlatforms();
    }
    void Update()
    {
        if (AtEncounter)
        {
           // SpawnPlatforms();
        }

    }

    void GeneratePool()
    {
        PlatformsPool = new List<GameObject>();
        Instantiate(SpawnPlatform, transform.position, Quaternion.identity);

        // spawns them wayyy off screen
        for (int i = 0; i < PlatformsToSpawn; i++)
        {
            PlatformsPool.Add(Instantiate(PlainPlatform, Vector3.up * (i+1) * 100, Quaternion.identity));
        }
        List<int> indexes = new List<int>();
        int ind;
        for (int i = 0; i < AmountOfObstacles; i++) 
        {
            do
            {
                ind = Random.Range(1, PlatformsToSpawn);
            } while (indexes.Contains(ind));
            // obstacles can never spawn together
            indexes.Add(ind);
            indexes.Add(ind + 1);
            indexes.Add(ind - 1);
            
            Object.Destroy(PlatformsPool[ind]);
            //GameObject ObstacleToSpawn = Obstacles[Random.Range(0, UniqueObstacles)];
            PlatformsPool[ind] = Instantiate(Obstacles[Random.Range(0, UniqueObstacles)], Vector3.up * ind * 100, Quaternion.identity);
        }

        PlatformsPool.Add(Instantiate(Encounter, Vector3.up * (PlatformsToSpawn + 1) * 100, Quaternion.identity));
    }

    public void SpawnPlatforms()
    {
        GeneratePool();

        Vector3 Position = transform.position;
   
        for (int i = 0; i < PlatformsPool.Count; i++)
        {
            Position.z += PlatformLength;
            transform.position = Position;

            PlatformsPool[i].gameObject.transform.position = Position;
        }
    }

    public void DestroyPlatforms()
    {
        for (int i = 0;i < PlatformsPool.Count;i++)
        {
            GameObject.Destroy(PlatformsPool[i]);
        }
    }
}

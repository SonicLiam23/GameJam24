using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;
using Unity.VisualScripting;

public class Timer : MonoBehaviour
{
    [SerializeField]
    public float m_time;
    [SerializeField]
    private bool m_isTimeOn;
    [SerializeField]
    private TextMeshProUGUI m_timer;

    void Update()
    {
        m_isTimeOn = true;

        if(m_time > 0)
        {
            m_time -= Time.deltaTime;
        }
        else if(m_time < 0)
        {
            m_time = 0;
            m_isTimeOn = false;

            Application.Quit();
        }

        int minutes = Mathf.FloorToInt(m_time / 60);
        int seconds = Mathf.FloorToInt(m_time % 60);
        m_timer.text = string.Format("{0:00}:{1:00}", minutes, seconds);
    }
}
